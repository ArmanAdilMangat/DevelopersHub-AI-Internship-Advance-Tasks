"""
Streamlit demo: paste a support ticket, see top-3 tags from each model.

Run:
    streamlit run app.py
"""
from pathlib import Path
import numpy as np
import pandas as pd
import streamlit as st
import torch

PROJECT = Path(__file__).resolve().parent
MODELS_DIR = PROJECT / "models"
DATA_DIR = PROJECT / "data"

st.set_page_config(page_title="Support Ticket Auto-Tagger", page_icon=":label:", layout="wide")
st.title("Support Ticket Auto-Tagger")
st.caption("Top-3 tag predictions from three LLM-based classifiers.")


# ----- Hypothesis map (mirrors zero_shot.py) -----
LABEL_TO_HYPOTHESIS = {
    "ACCOUNT":          "user account, login, registration, or password",
    "CANCEL":           "cancelling an order or subscription",
    "CANCELLATION_FEE": "cancellation fees or charges",
    "CONTACT":          "contacting customer service or support",
    "DELIVERY":         "delivery status, tracking, or delivery options",
    "FEEDBACK":         "leaving feedback, reviews, or complaints",
    "INVOICE":          "invoices, billing statements, or receipts",
    "NEWSLETTER":       "newsletter subscription or unsubscribe",
    "ORDER":            "placing, modifying, or checking an order",
    "PAYMENT":          "payment methods, payment issues, or charges",
    "REFUND":           "refunds, returns, or money back",
    "SHIPPING_ADDRESS": "shipping address or address change",
    "SHIPPING":         "shipping options, costs, or delivery",
    "SUBSCRIPTION":     "subscription management",
}


# ----- Cached loaders -----
@st.cache_resource
def load_zero_shot():
    from transformers import pipeline
    return pipeline("zero-shot-classification", model="facebook/bart-large-mnli", device=-1)


@st.cache_resource
def load_setfit():
    from setfit import SetFitModel
    path = MODELS_DIR / "setfit"
    if not path.exists():
        return None
    return SetFitModel.from_pretrained(str(path))


@st.cache_resource
def load_distilbert():
    from transformers import AutoTokenizer, AutoModelForSequenceClassification
    path = MODELS_DIR / "distilbert-finetuned"
    if not path.exists():
        return None, None
    tok = AutoTokenizer.from_pretrained(str(path))
    mdl = AutoModelForSequenceClassification.from_pretrained(str(path))
    mdl.eval()
    return tok, mdl


@st.cache_data
def load_labels():
    p = DATA_DIR / "labels.txt"
    if not p.exists():
        return []
    return [l.strip() for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]


# ----- Top-3 functions -----
def top3_zero_shot(text, labels):
    clf = load_zero_shot()
    hyps = [LABEL_TO_HYPOTHESIS.get(l, l.lower().replace("_", " ")) for l in labels]
    hyp_to_label = dict(zip(hyps, labels))
    out = clf(text, candidate_labels=hyps, multi_label=False)
    return [(hyp_to_label[lab], score) for lab, score in zip(out["labels"][:3], out["scores"][:3])]


def top3_setfit(text, labels):
    model = load_setfit()
    if model is None:
        return None
    probs = np.asarray(model.predict_proba([text]))[0]
    sorted_labels = sorted(labels)  # SetFit was trained with alphabetical label IDs
    idx = np.argsort(-probs)[:3]
    return [(sorted_labels[i], float(probs[i])) for i in idx]


def top3_distilbert(text, _labels):
    tok, mdl = load_distilbert()
    if mdl is None:
        return None
    enc = tok(text, return_tensors="pt", truncation=True, max_length=128)
    with torch.no_grad():
        logits = mdl(**enc).logits[0]
    probs = torch.softmax(logits, dim=-1).numpy()
    id2label = mdl.config.id2label
    idx = np.argsort(-probs)[:3]
    return [(id2label[int(i)], float(probs[i])) for i in idx]


def render(predictions, title, missing_hint):
    st.subheader(title)
    if predictions is None:
        st.warning(missing_hint)
        return
    df = pd.DataFrame(predictions, columns=["Tag", "Score"])
    df["Score"] = df["Score"].apply(lambda x: f"{x:.3f}")
    st.dataframe(df, use_container_width=True, hide_index=True)


# ----- UI -----
labels = load_labels()
if not labels:
    st.error("`data/labels.txt` not found. Run `python src/load_data.py` first.")
    st.stop()

text = st.text_area(
    "Paste a support ticket:",
    "I want to cancel my last order and get a refund. Can you help?",
    height=120,
)

if st.button("Tag this ticket", type="primary") and text.strip():
    c1, c2, c3 = st.columns(3)
    with c1:
        with st.spinner("Zero-shot..."):
            render(top3_zero_shot(text, labels),
                   "Zero-Shot (BART-MNLI)",
                   "Always available; first run downloads ~1.6GB.")
    with c2:
        with st.spinner("Few-shot..."):
            render(top3_setfit(text, labels),
                   "Few-Shot (SetFit)",
                   "Run `python src/few_shot_setfit.py` first.")
    with c3:
        with st.spinner("Fine-tuned..."):
            render(top3_distilbert(text, labels),
                   "Fine-Tuned (DistilBERT)",
                   "Run `python src/fine_tune_distilbert.py` first.")

st.divider()
st.caption(
    "Categories: " + ", ".join(labels)
)

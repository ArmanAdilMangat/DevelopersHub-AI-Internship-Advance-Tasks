"""
Fine-tune distilbert-base-uncased on the full Bitext training set.

Designed for Google Colab (T4 GPU, ~15-20 min). Will technically run on
CPU but will take many hours -- use Colab.

Outputs:
    models/distilbert-finetuned/         (HF saved model + tokenizer)
    results/preds_fine_tuned.csv         (predictions on full test.csv)
    results/preds_fine_tuned_small.csv   (predictions on test_small.csv,
                                          for apples-to-apples comparison)

Run:
    python src/fine_tune_distilbert.py
"""
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from datasets import Dataset
from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    Trainer,
    TrainingArguments,
    DataCollatorWithPadding,
)

PROJECT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT / "data"
RESULTS_DIR = PROJECT / "results"
MODELS_DIR = PROJECT / "models"
RESULTS_DIR.mkdir(exist_ok=True)
MODELS_DIR.mkdir(exist_ok=True)

BASE_MODEL = "distilbert-base-uncased"
OUTPUT_DIR = MODELS_DIR / "distilbert-finetuned"

MAX_LEN = 128
BATCH_SIZE = 32
EPOCHS = 3
LR = 2e-5
RANDOM_STATE = 42


def predict_top3(trainer, ds_to_predict, df_with_labels, id2label, out_path):
    """Run trainer.predict and write a top-3 CSV in the same format as the
    other models so evaluate.py can consume them all uniformly."""
    pred_out = trainer.predict(ds_to_predict)
    logits = pred_out.predictions
    probs = torch.softmax(torch.tensor(logits), dim=-1).numpy()
    top3_idx = np.argsort(-probs, axis=1)[:, :3]

    rows = []
    for i, (_, r) in enumerate(df_with_labels.iterrows()):
        rows.append({
            "text": r["text"],
            "true_label": r["label"],
            "pred_1": id2label[int(top3_idx[i, 0])], "score_1": round(float(probs[i, top3_idx[i, 0]]), 4),
            "pred_2": id2label[int(top3_idx[i, 1])], "score_2": round(float(probs[i, top3_idx[i, 1]]), 4),
            "pred_3": id2label[int(top3_idx[i, 2])], "score_3": round(float(probs[i, top3_idx[i, 2]]), 4),
        })
    pd.DataFrame(rows).to_csv(out_path, index=False)
    print(f"Saved: {out_path}")


def main():
    train_df = pd.read_csv(DATA_DIR / "train.csv")
    test_df = pd.read_csv(DATA_DIR / "test.csv")
    test_small_df = pd.read_csv(DATA_DIR / "test_small.csv")

    labels = sorted(train_df["label"].unique())
    label2id = {l: i for i, l in enumerate(labels)}
    id2label = {i: l for l, i in label2id.items()}

    for d in (train_df, test_df, test_small_df):
        d["label_id"] = d["label"].map(label2id)

    tokenizer = AutoTokenizer.from_pretrained(BASE_MODEL)

    def tok(batch):
        return tokenizer(batch["text"], truncation=True, max_length=MAX_LEN)

    def to_ds(df):
        return (
            Dataset.from_pandas(df[["text", "label_id"]].rename(columns={"label_id": "labels"}))
            .map(tok, batched=True)
        )

    train_ds = to_ds(train_df)
    test_ds = to_ds(test_df)
    test_small_ds = to_ds(test_small_df)

    model = AutoModelForSequenceClassification.from_pretrained(
        BASE_MODEL,
        num_labels=len(labels),
        id2label=id2label,
        label2id=label2id,
    )

    args = TrainingArguments(
        output_dir=str(OUTPUT_DIR),
        num_train_epochs=EPOCHS,
        per_device_train_batch_size=BATCH_SIZE,
        per_device_eval_batch_size=BATCH_SIZE,
        learning_rate=LR,
        weight_decay=0.01,
        eval_strategy="epoch",
        save_strategy="epoch",
        load_best_model_at_end=True,
        metric_for_best_model="eval_loss",
        greater_is_better=False,
        logging_steps=50,
        seed=RANDOM_STATE,
        report_to="none",
        save_total_limit=1,
    )

    trainer = Trainer(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=test_ds,
        tokenizer=tokenizer,
        data_collator=DataCollatorWithPadding(tokenizer=tokenizer),
    )

    print("Training...")
    trainer.train()
    print("Done.")

    print("Saving model...")
    trainer.save_model(str(OUTPUT_DIR))
    tokenizer.save_pretrained(str(OUTPUT_DIR))

    print("Predicting on full test.csv...")
    predict_top3(trainer, test_ds, test_df, id2label,
                 RESULTS_DIR / "preds_fine_tuned.csv")

    print("Predicting on test_small.csv (for direct comparison)...")
    predict_top3(trainer, test_small_ds, test_small_df, id2label,
                 RESULTS_DIR / "preds_fine_tuned_small.csv")


if __name__ == "__main__":
    main()
